PROJECT AIT

Projeto Android atualizado com:
- Interface escura
- Pesquisa no topo
- Importação de múltiplos arquivos pelo seletor Android
- Cópia dos arquivos para o armazenamento privado do aplicativo
- Listagem com formato e tamanho
- Abertura por aplicativos compatíveis
- Renomear, consultar informações e excluir

Pacote: com.devkaua.projetotudoemum
Nome exibido: Project AIT

IMPORTANTE
Este ZIP contém o código-fonte de um projeto Android Gradle, não um APK compilado.
O projeto recebido já estava no formato Gradle com Java e View Binding; não era um arquivo-fonte nativo de blocos do Sketchware. Por isso, a implementação foi feita diretamente nesse projeto, preservando sua estrutura Gradle.

Para compilar, abra/import o projeto em um ambiente Android Gradle compatível. A compilação não foi executada neste ambiente, portanto ainda é necessário compilar e testar no aparelho.
Os arquivos importados ficam na pasta privada do app. Desinstalar o app ou limpar os dados apaga essa biblioteca.
