package com.devkaua.projetotudoemum;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_FILES = 410;
    private static final int BG = Color.rgb(15, 20, 30);
    private static final int SURFACE = Color.rgb(29, 39, 55);
    private static final int SURFACE_ALT = Color.rgb(37, 49, 68);
    private static final int TEXT = Color.rgb(244, 247, 252);
    private static final int MUTED = Color.rgb(166, 180, 200);
    private static final int ACCENT = Color.rgb(55, 125, 224);
    private LinearLayout root;
    private LinearLayout fileList;
    private EditText search;
    private TextView count;
    private TextView empty;
    private File library;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        library = new File(getFilesDir(), "library");
        if (!library.exists()) library.mkdirs();
        buildScreen();
        refreshFiles("");
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h));
    }

    private void buildScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        setContentView(root);

        TextView title = text("Project AIT", 25, TEXT, true);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title, lp(-1, 42));

        TextView subtitle = text("Sua biblioteca de arquivos", 13, MUTED, false);
        LinearLayout.LayoutParams subParams = lp(-1, 25);
        subParams.bottomMargin = dp(17);
        root.addView(subtitle, subParams);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextSize(15);
        search.setTextColor(TEXT);
        search.setHintTextColor(MUTED);
        search.setHint("Pesquisar arquivos...");
        search.setCompoundDrawablesWithIntrinsicBounds(android.R.drawable.ic_menu_search, 0, 0, 0);
        search.setCompoundDrawablePadding(dp(10));
        search.setPadding(dp(14), 0, dp(14), 0);
        search.setBackground(shape(SURFACE, 14));
        root.addView(search, lp(-1, 52));
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                refreshFiles(s.toString());
            }
            public void afterTextChanged(android.text.Editable e) {}
        });

        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams headingParams = lp(-1, 48);
        headingParams.topMargin = dp(12);
        root.addView(heading, headingParams);

        TextView libraryTitle = text("Minha biblioteca", 17, TEXT, true);
        heading.addView(libraryTitle, new LinearLayout.LayoutParams(0, -2, 1));
        count = text("0 arquivos", 12, MUTED, false);
        heading.addView(count);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        fileList = new LinearLayout(this);
        fileList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(fileList, new ScrollView.LayoutParams(-1, -2));

        empty = text("Sua biblioteca está vazia.\nToque em Adicionar arquivos para começar.", 14, MUTED, false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(18), dp(35), dp(18), dp(35));
        fileList.addView(empty, lp(-1, -2));

        Button add = new Button(this);
        add.setText("＋  Adicionar arquivos");
        add.setTextColor(Color.WHITE);
        add.setTextSize(15);
        add.setAllCaps(false);
        add.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        add.setBackground(shape(ACCENT, 16));
        LinearLayout.LayoutParams addParams = lp(-1, 54);
        addParams.topMargin = dp(14);
        root.addView(add, addParams);
        add.setOnClickListener(v -> chooseFiles());
    }

    private void chooseFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(intent, REQUEST_FILES);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FILES || resultCode != RESULT_OK || data == null) return;
        int imported = 0;
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                Uri uri = data.getClipData().getItemAt(i).getUri();
                if (copyIntoLibrary(uri)) imported++;
            }
        } else if (data.getData() != null && copyIntoLibrary(data.getData())) {
            imported++;
        }
        refreshFiles(search.getText().toString());
        Toast.makeText(this, imported + (imported == 1 ? " arquivo importado" : " arquivos importados"), Toast.LENGTH_SHORT).show();
    }

    private boolean copyIntoLibrary(Uri uri) {
        String name = queryName(uri);
        if (name == null || name.trim().isEmpty()) name = "arquivo";
        name = cleanName(name);
        File destination = uniqueFile(name);
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(destination)) {
            if (in == null) return false;
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return true;
        } catch (Exception e) {
            if (destination.exists()) destination.delete();
            Toast.makeText(this, "Não foi possível importar " + name, Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private String queryName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return uri.getLastPathSegment();
    }

    private String cleanName(String name) {
        return name.replace("/", "_").replace("\\", "_").trim();
    }

    private File uniqueFile(String name) {
        File f = new File(library, name);
        if (!f.exists()) return f;
        String base = name;
        String ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) {
            base = name.substring(0, dot);
            ext = name.substring(dot);
        }
        int i = 2;
        do {
            f = new File(library, base + " (" + i++ + ")" + ext);
        } while (f.exists());
        return f;
    }

    private ArrayList<File> allFiles() {
        ArrayList<File> files = new ArrayList<>();
        File[] list = library.listFiles();
        if (list != null) {
            for (File f : list) if (f.isFile()) files.add(f);
        }
        Collections.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        return files;
    }

    private void refreshFiles(String filter) {
        if (fileList == null) return;
        fileList.removeAllViews();
        ArrayList<File> files = allFiles();
        int total = files.size();
        count.setText(total + (total == 1 ? " arquivo" : " arquivos"));
        String q = filter == null ? "" : filter.trim().toLowerCase(Locale.ROOT);
        int shown = 0;
        for (File file : files) {
            if (!file.getName().toLowerCase(Locale.ROOT).contains(q)) continue;
            fileList.addView(fileRow(file), lp(-1, 76));
            LinearLayout.LayoutParams p = (LinearLayout.LayoutParams) fileList.getChildAt(fileList.getChildCount() - 1).getLayoutParams();
            p.bottomMargin = dp(9);
            fileList.getChildAt(fileList.getChildCount() - 1).setLayoutParams(p);
            shown++;
        }
        if (shown == 0) {
            empty.setText(total == 0 ? "Sua biblioteca está vazia.\nToque em Adicionar arquivos para começar." : "Nenhum arquivo encontrado.");
            fileList.addView(empty, lp(-1, -2));
        }
    }

    private View fileRow(File file) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(8), dp(8), dp(8));
        row.setBackground(shape(SURFACE_ALT, 14));

        TextView icon = text(fileIcon(file.getName()), 25, ACCENT, true);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, lp(42, 48));

        LinearLayout details = new LinearLayout(this);
        details.setOrientation(LinearLayout.VERTICAL);
        details.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(0, -1, 1);
        detailsParams.leftMargin = dp(10);
        row.addView(details, detailsParams);

        TextView name = text(file.getName(), 14, TEXT, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        details.addView(name, lp(-1, -2));
        TextView meta = text(fileType(file.getName()) + "  •  " + readableSize(file.length()), 11, MUTED, false);
        details.addView(meta, lp(-1, -2));

        TextView menu = text("⋮", 25, MUTED, true);
        menu.setGravity(Gravity.CENTER);
        row.addView(menu, lp(42, 48));
        row.setOnClickListener(v -> openFile(file));
        menu.setOnClickListener(v -> showFileMenu(file));
        return row;
    }

    private String fileIcon(String name) {
        String ext = extension(name);
        if (ext.equals("pdf")) return "▤";
        if (isImage(ext)) return "▧";
        if (ext.equals("zip") || ext.equals("rar") || ext.equals("7z")) return "▣";
        if (ext.equals("mp3") || ext.equals("wav") || ext.equals("ogg")) return "♫";
        if (ext.equals("mp4") || ext.equals("mkv") || ext.equals("avi")) return "▶";
        if (ext.equals("txt") || ext.equals("md")) return "≡";
        return "▤";
    }

    private String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    private boolean isImage(String ext) {
        return ext.equals("png") || ext.equals("jpg") || ext.equals("jpeg") || ext.equals("webp") || ext.equals("gif") || ext.equals("bmp");
    }

    private String fileType(String name) {
        String ext = extension(name);
        return ext.isEmpty() ? "ARQUIVO" : ext.toUpperCase(Locale.ROOT);
    }

    private String readableSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return new DecimalFormat("#,##0.0").format(bytes / 1024.0) + " KB";
        if (bytes < 1024L * 1024L * 1024L) return new DecimalFormat("#,##0.0").format(bytes / (1024.0 * 1024.0)) + " MB";
        return new DecimalFormat("#,##0.0").format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GB";
    }

    private void openFile(File file) {
        try {
            Uri uri = Uri.parse("content://" + getPackageName() + ".files/" + Uri.encode(file.getName()));
            String mime = getContentResolver().getType(uri);
            if (mime == null) mime = "*/*";
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Não há aplicativo compatível para abrir este arquivo.", Toast.LENGTH_LONG).show();
        }
    }

    private void showFileMenu(File file) {
        String[] options = {"Abrir", "Renomear", "Informações", "Excluir"};
        new AlertDialog.Builder(this)
            .setTitle(file.getName())
            .setItems(options, (dialog, which) -> {
                if (which == 0) openFile(file);
                if (which == 1) renameFile(file);
                if (which == 2) showInfo(file);
                if (which == 3) confirmDelete(file);
            }).show();
    }

    private void renameFile(File file) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(file.getName());
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
            .setTitle("Renomear arquivo")
            .setView(input)
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Salvar", (d, w) -> {
                String value = cleanName(input.getText().toString());
                if (value.isEmpty()) return;
                File target = new File(library, value);
                if (target.exists()) {
                    Toast.makeText(this, "Já existe um arquivo com esse nome.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (file.renameTo(target)) refreshFiles(search.getText().toString());
                else Toast.makeText(this, "Não foi possível renomear o arquivo.", Toast.LENGTH_SHORT).show();
            }).show();
    }

    private void showInfo(File file) {
        String info = "Nome: " + file.getName() + "\nFormato: " + fileType(file.getName()) +
            "\nTamanho: " + readableSize(file.length()) +
            "\nModificado: " + android.text.format.DateFormat.format("dd/MM/yyyy HH:mm", file.lastModified());
        new AlertDialog.Builder(this).setTitle("Informações").setMessage(info).setPositiveButton("Fechar", null).show();
    }

    private void confirmDelete(File file) {
        new AlertDialog.Builder(this)
            .setTitle("Excluir arquivo?")
            .setMessage("O arquivo \"" + file.getName() + "\" será removido da biblioteca.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Excluir", (d, w) -> {
                if (file.delete()) refreshFiles(search.getText().toString());
                else Toast.makeText(this, "Não foi possível excluir o arquivo.", Toast.LENGTH_SHORT).show();
            }).show();
    }
}
